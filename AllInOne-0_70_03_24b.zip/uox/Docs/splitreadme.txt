In the NPC.scp

add these commands to any npc

SPLIT ##
SPLITCHANCE ##


where SPLIT is how many it can split into when hit

SPLIT 3

it has a posibility of spliting up to 3 extra npcs each time hit

and where SPLITCHANCE is the chance that an NPC has to split when hit


SPLITCHANCE 70

the npc has a 70 percent chace of splitting each time hit.

slime is usually 50 percent




